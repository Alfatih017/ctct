const accountService = require('../services/accountService');
const transactionService = require('../services/transactionService');
const logger = require('../utils/logger');
const { isAuthorized } = require('../utils/auth');

module.exports = async (bot, query) => {
    const chatId = query.message.chat.id;
    const data = query.data;

    logger.info(`Received callback query from ${chatId}: ${data}`);

    if (!isAuthorized(chatId)) {
        bot.answerCallbackQuery(query.id, { text: 'Anda tidak memiliki akses.' });
        return;
    }

    try {
        if (data.startsWith('view_accounts')) {
            await accountService.showAccounts(bot, chatId);
        } else if (data.startsWith('add_account')) {
            await accountService.startAddAccount(bot, chatId);
        } else if (data.startsWith('update_account_')) {
            const accountNo = parseInt(data.split('_')[2]);
            await transactionService.updateTransaction(bot, chatId, accountNo);
        } else if (data.startsWith('trx_type_')) {
            const [_, accountNo, type] = data.split('_');
            await transactionService.handleTransactionType(bot, chatId, accountNo, type);
        } else if (data.startsWith('list_all_accounts')) {
            await accountService.listAllAccounts(bot, chatId);
        } else if (data.startsWith('edit_account')) {
            await accountService.showAccountsForEdit(bot, chatId);
        } else if (data.startsWith('delete_account')) {
            await accountService.showAccountsForDelete(bot, chatId);
        } else if (data.startsWith('total_transactions_today')) {
            await transactionService.showTotalTransactionsToday(bot, chatId);
        } else if (data.startsWith('search_account')) {
            await accountService.startSearchAccount(bot, chatId);
        } else if (data.startsWith('account_detail_')) {
            const accountNo = parseInt(data.split('_')[2]);
            await accountService.showAccountDetail(bot, chatId, accountNo);
        } else if (data.startsWith('transaction_history_')) {
            const accountNo = parseInt(data.split('_')[2]);
            await transactionService.showTransactionHistory(bot, chatId, accountNo);
        } else if (data === 'back_to_menu') {
            const { mainMenuKeyboard } = require('../utils/keyboard');
            await bot.sendMessage(chatId, 'Menu Utama:', {
                reply_markup: mainMenuKeyboard()
            });
        }
    } catch (error) {
        logger.error('Error handling callback query:', error);
        bot.answerCallbackQuery(query.id, { text: 'Terjadi kesalahan. Silakan coba lagi.' });
    }

    bot.answerCallbackQuery(query.id);
};