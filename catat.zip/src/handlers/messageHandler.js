const accountService = require('../services/accountService');
const transactionService = require('../services/transactionService');
const logger = require('../utils/logger');
const { isAuthorized } = require('../utils/auth');

module.exports = (bot, msg) => {
    const chatId = msg.chat.id;
    const messageText = msg.text;

    logger.info(`Received message from ${chatId}: ${messageText}`);

    if (!isAuthorized(chatId)) {
        bot.sendMessage(chatId, 'Maaf, Anda tidak memiliki akses ke bot ini.');
        return;
    }

    if (messageText.startsWith('/')) {
        // Command handling is done separately
        return;
    }

    if (accountService.isAddingAccount(chatId)) {
        const response = accountService.handleAddAccount(chatId, messageText);
        bot.sendMessage(chatId, response);
    } else if (transactionService.isUpdatingTransaction(chatId)) {
        const response = transactionService.handleUpdateTransaction(chatId, messageText);
        bot.sendMessage(chatId, response);
    } else {
        // Default response or ignore
    }
};