const fs = require('fs');
const logger = require('../utils/logger');
const { chunk } = require('../utils/helpers');

let accounts = [];
let addAccountState = {};

if (fs.existsSync('accounts.json')) {
    accounts = JSON.parse(fs.readFileSync('accounts.json'));
}

function saveAccounts() {
    fs.writeFileSync('accounts.json', JSON.stringify(accounts, null, 2));
}

function isAddingAccount(chatId) {
    return !!addAccountState[chatId];
}

async function startAddAccount(bot, chatId) {
    addAccountState[chatId] = { step: 'email' };
    await bot.sendMessage(chatId, 'Silakan masukkan email untuk akun baru:');
}

function handleAddAccount(chatId, message) {
    const state = addAccountState[chatId];
    if (state.step === 'email') {
        state.email = message;
        state.step = 'address';
        return 'Email berhasil ditambahkan. Sekarang masukkan alamat untuk akun ini:';
    } else if (state.step === 'address') {
        const newAccount = {
            no: accounts.length + 1,
            email: state.email,
            address: message,
            lastTrx: 'Belum ada transaksi'
        };
        accounts.push(newAccount);
        delete addAccountState[chatId];
        saveAccounts();
        logger.info(`New account added: ${newAccount.email}`);
        return `Akun berhasil ditambahkan:\nNo: ${newAccount.no}\nEmail: ${newAccount.email}\nAddress: ${newAccount.address}`;
    }
}

async function showAccounts(bot, chatId) {
    if (accounts.length === 0) {
        await bot.sendMessage(chatId, 'Belum ada akun yang terdaftar.');
        return;
    }

    const accountChunks = chunk(accounts, 3);
    const keyboard = accountChunks.map(chunk =>
        chunk.map(acc => ({ text: `${acc.no}. ${acc.email}`, callback_data: `account_detail_${acc.no}` }))
    );
    keyboard.push([{ text: '🔙 Kembali ke Menu', callback_data: 'back_to_menu' }]);

    await bot.sendMessage(chatId, 'Daftar Akun:\nPilih akun untuk melihat detail:', {
        reply_markup: { inline_keyboard: keyboard }
    });
}

async function listAllAccounts(bot, chatId, page = 1) {
    if (accounts.length === 0) {
        await bot.sendMessage(chatId, 'Belum ada akun yang terdaftar.');
        return;
    }

    const pageSize = 10;
    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const accountsToShow = accounts.slice(startIndex, endIndex);

    let accountList = accountsToShow.map(acc => 
        `No: ${acc.no}\nEmail: ${acc.email}\nAddress: ${acc.address}\nLast Trx: ${acc.lastTrx}\n${acc.transactionDetails ? `Detail: ${acc.transactionDetails}\n` : ''}\n`
    ).join('\n');

    const totalPages = Math.ceil(accounts.length / pageSize);
    
    const keyboard = [];
    if (page > 1) {
        keyboard.push([{ text: '⬅️ Previous', callback_data: `list_accounts_${page - 1}` }]);
    }
    if (page < totalPages) {
        keyboard.push([{ text: '➡️ Next', callback_data: `list_accounts_${page + 1}` }]);
    }
    keyboard.push([{ text: '🔙 Kembali ke Menu', callback_data: 'back_to_menu' }]);

    await bot.sendMessage(chatId, `Daftar Akun (Halaman ${page}/${totalPages}):\n\n${accountList}`, {
        reply_markup: { inline_keyboard: keyboard }
    });
}

async function showAccountDetail(bot, chatId, accountNo) {
    const account = accounts.find(acc => acc.no === accountNo);
    if (account) {
        let detailMessage = `Detail Akun:\n\nNo: ${account.no}\nEmail: ${account.email}\nAddress: ${account.address}\nLast Trx: ${account.lastTrx}\n`;
        if (account.transactionDetails) {
            detailMessage += `Detail Transaksi: ${account.transactionDetails}\n`;
        }

        await bot.sendMessage(chatId, detailMessage, {
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'Edit Waktu Transaksi', callback_data: `edit_time_${account.no}` }],
                    [{ text: 'Edit Detail Transaksi', callback_data: `edit_detail_${account.no}` }],
                    [{ text: '🔙 Kembali', callback_data: 'view_accounts' }]
                ]
            }
        });
    } else {
        await bot.sendMessage(chatId, `Akun dengan nomor ${accountNo} tidak ditemukan.`);
    }
}

// ... (tambahkan fungsi lain seperti showAccountsForEdit, showAccountsForDelete, startSearchAccount, dll.)

module.exports = {
    isAddingAccount,
    startAddAccount,
    handleAddAccount,
    showAccounts,
    listAllAccounts,
    showAccountDetail,
    // ... export fungsi lainnya
};