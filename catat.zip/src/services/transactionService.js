const fs = require('fs');
const logger = require('../utils/logger');
const { getCurrentTimeUTC8, formatTime } = require('../utils/dateTime');
const { encrypt, decrypt } = require('../utils/encryption');

let accounts = [];
let transactionDetailState = {};

if (fs.existsSync('accounts.json')) {
    accounts = JSON.parse(fs.readFileSync('accounts.json'));
    // Decrypt sensitive data
    accounts = accounts.map(account => ({
        ...account,
        email: decrypt(account.email),
        address: decrypt(account.address)
    }));
}

function saveAccounts() {
    // Encrypt sensitive data before saving
    const encryptedAccounts = accounts.map(account => ({
        ...account,
        email: encrypt(account.email),
        address: encrypt(account.address)
    }));
    fs.writeFileSync('accounts.json', JSON.stringify(encryptedAccounts, null, 2));
}

function isUpdatingTransaction(chatId) {
    return !!transactionDetailState[chatId];
}

async function showAccountsForUpdate(bot, chatId) {
    if (accounts.length === 0) {
        await bot.sendMessage(chatId, 'Belum ada akun yang terdaftar.');
        return;
    }

    const keyboard = accounts.map(acc => [{ text: `${acc.no}. ${acc.email}`, callback_data: `update_account_${acc.no}` }]);
    keyboard.push([{ text: '🔙 Kembali ke Menu', callback_data: 'back_to_menu' }]);

    await bot.sendMessage(chatId, 'Pilih akun untuk update transaksi:', {
        reply_markup: { inline_keyboard: keyboard }
    });
}

async function updateTransaction(bot, chatId, accountNo) {
    const account = accounts.find(acc => acc.no === accountNo);
    if (account) {
        transactionDetailState[chatId] = { accountNo, step: 'type' };
        const typeKeyboard = [
            [{ text: 'Deposit', callback_data: `trx_type_${accountNo}_Deposit` }],
            [{ text: 'Withdrawal', callback_data: `trx_type_${accountNo}_Withdrawal` }],
            [{ text: 'Transfer', callback_data: `trx_type_${accountNo}_Transfer` }],
            [{ text: 'Payment', callback_data: `trx_type_${accountNo}_Payment` }],
            [{ text: 'Refund', callback_data: `trx_type_${accountNo}_Refund` }],
            [{ text: 'Other', callback_data: `trx_type_${accountNo}_Other` }]
        ];
        await bot.sendMessage(chatId, 'Pilih tipe transaksi:', {
            reply_markup: { inline_keyboard: typeKeyboard }
        });
    } else {
        await bot.sendMessage(chatId, `Akun dengan nomor ${accountNo} tidak ditemukan.`);
    }
}

async function handleTransactionType(bot, chatId, accountNo, type) {
    const account = accounts.find(acc => acc.no === parseInt(accountNo));
    if (account) {
        const now = getCurrentTimeUTC8();
        const formattedDate = formatTime(now);
        
        // Add new transaction to the account's transaction history
        if (!account.transactions) {
            account.transactions = [];
        }
        account.transactions.push({
            type: type,
            timestamp: formattedDate
        });
        
        account.lastTrx = formattedDate;
        saveAccounts();
        
        await bot.sendMessage(chatId, `Transaksi ${type} untuk akun no ${accountNo} berhasil dicatat.\n\nWaktu update (UTC+8): ${formattedDate}`);
        
        // Show updated transaction count for today
        const todayTransactions = account.transactions.filter(t => t.timestamp.split(' ')[0] === formattedDate.split(' ')[0]);
        await bot.sendMessage(chatId, `Total transaksi hari ini untuk akun ini: ${todayTransactions.length}`);
    } else {
        await bot.sendMessage(chatId, `Akun dengan nomor ${accountNo} tidak ditemukan.`);
    }
    delete transactionDetailState[chatId];
}

async function showTotalTransactionsToday(bot, chatId) {
    const today = getCurrentTimeUTC8();
    const todayStr = formatTime(today).split(' ')[0];
    
    let totalTransactions = 0;
    accounts.forEach(account => {
        if (account.transactions) {
            totalTransactions += account.transactions.filter(t => t.timestamp.startsWith(todayStr)).length;
        }
    });

    const calculation = totalTransactions * 0.0002;

    const message = `📊 Total transaksi hari ini (${todayStr}): ${totalTransactions}\n` +
                    `${totalTransactions} * 0.0002 = ${calculation.toFixed(4)}\n` +
                    `💲 = ${calculation.toFixed(2)}`;

    await bot.sendMessage(chatId, message, {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🔙 Kembali ke Menu', callback_data: 'back_to_menu' }]
            ]
        }
    });
}

async function showTransactionHistory(bot, chatId, accountNo) {
    const account = accounts.find(acc => acc.no === parseInt(accountNo));
    if (account && account.transactions) {
        const today = getCurrentTimeUTC8();
        const todayStr = formatTime(today).split(' ')[0];
        const todayTransactions = account.transactions.filter(t => t.timestamp.startsWith(todayStr));
        
        let message = `Riwayat transaksi hari ini untuk akun ${account.email}:\n\n`;
        todayTransactions.forEach((t, index) => {
            message += `${index + 1}. ${t.type} - ${t.timestamp}\n`;
        });
        
        message += `\nTotal transaksi hari ini: ${todayTransactions.length}`;
        
        await bot.sendMessage(chatId, message, {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔙 Kembali ke Menu', callback_data: 'back_to_menu' }]
                ]
            }
        });
    } else {
        await bot.sendMessage(chatId, `Akun dengan nomor ${accountNo} tidak ditemukan atau belum memiliki transaksi.`);
    }
}

module.exports = {
    isUpdatingTransaction,
    showAccountsForUpdate,
    updateTransaction,
    handleTransactionType,
    showTotalTransactionsToday,
    showTransactionHistory
};