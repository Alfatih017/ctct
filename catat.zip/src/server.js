const express = require('express');
const helmet = require('helmet');
const bot = require('./bot');
const config = require('./config/config');

const app = express();

app.use(helmet());
app.use(express.json());

app.post(`/bot${config.TELEGRAM_BOT_TOKEN}`, (req, res) => {
    bot.processUpdate(req.body);
    res.sendStatus(200);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});