require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const config = require('./config/config');
const messageHandler = require('./handlers/messageHandler');
const callbackQueryHandler = require('./handlers/callbackQueryHandler');
const logger = require('./utils/logger');
const { setupCommands } = require('./utils/setupCommands');

const bot = new TelegramBot(config.TELEGRAM_BOT_TOKEN, { polling: true });

setupCommands(bot);

bot.on('message', (msg) => messageHandler(bot, msg));
bot.on('callback_query', (query) => callbackQueryHandler(bot, query));

bot.on('polling_error', (error) => {
  logger.error('Polling error:', error);
});

logger.info('Bot is running...');

module.exports = bot;