const fs = require('fs');
const path = require('path');
const logger = require('./logger');

function setupCommands(bot) {
    const commandsPath = path.join(__dirname, '..', 'commands');
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

    for (const file of commandFiles) {
        const command = require(path.join(commandsPath, file));
        bot.onText(new RegExp(`^${command.command}$`), (msg) => {
            command.handler(bot, msg);
        });
        logger.info(`Command ${command.command} has been set up`);
    }
}

module.exports = {
    setupCommands
};