function mainMenuKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '👀 Lihat Akun', callback_data: 'view_accounts' }, { text: '➕ Tambah Akun', callback_data: 'add_account' }],
            [{ text: '🔄 Update Transaksi', callback_data: 'update_transaction' }, { text: '📋 Daftar Semua Akun', callback_data: 'list_all_accounts' }],
            [{ text: '✏️ Edit Akun', callback_data: 'edit_account' }, { text: '🗑️ Hapus Akun', callback_data: 'delete_account' }],
            [{ text: '📊 Total Transaksi Hari Ini', callback_data: 'total_transactions_today' }],
            [{ text: '📜 Riwayat Transaksi', callback_data: 'view_accounts' }],
            [{ text: '🔍 Cari Akun', callback_data: 'search_account' }]
        ]
    };
}

module.exports = {
    mainMenuKeyboard
};