const config = require('../config/config');
const bcrypt = require('bcrypt');

function isAuthorized(chatId) {
    if (!config.ADMIN_CHAT_ID) return true;
    return chatId.toString() === config.ADMIN_CHAT_ID;
}

async function hashPassword(password) {
    return await bcrypt.hash(password, 10);
}

async function comparePassword(password, hash) {
    return await bcrypt.compare(password, hash);
}

module.exports = {
    isAuthorized,
    hashPassword,
    comparePassword
};