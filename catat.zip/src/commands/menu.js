const { mainMenuKeyboard } = require('../utils/keyboard');
const logger = require('../utils/logger');

module.exports = {
    command: '/menu',
    description: 'Tampilkan menu utama',
    handler: (bot, msg) => {
        const chatId = msg.chat.id;
        logger.info(`Menu command initiated by user ${chatId}`);
        bot.sendMessage(chatId, 'Menu Utama:', {
            reply_markup: mainMenuKeyboard()
        });
    }
};