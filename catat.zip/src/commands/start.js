const { mainMenuKeyboard } = require('../utils/keyboard');
const logger = require('../utils/logger');

module.exports = {
    command: '/start',
    description: 'Mulai bot / Tampilkan menu utama',
    handler: (bot, msg) => {
        const chatId = msg.chat.id;
        logger.info(`Start command initiated by user ${chatId}`);
        bot.sendMessage(chatId, 'Selamat datang di Bot Manajemen Akun!', {
            reply_markup: mainMenuKeyboard()
        });
    }
};